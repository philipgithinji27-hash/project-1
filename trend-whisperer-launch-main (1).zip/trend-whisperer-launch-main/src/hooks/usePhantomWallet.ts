import { useState, useEffect, useCallback } from "react";

interface PhantomProvider {
  isPhantom?: boolean;
  connect: () => Promise<{ publicKey: { toString: () => string } }>;
  disconnect: () => Promise<void>;
  on: (event: string, callback: (...args: any[]) => void) => void;
  off: (event: string, callback: (...args: any[]) => void) => void;
  publicKey: { toString: () => string } | null;
  isConnected: boolean;
  signTransaction: (transaction: any) => Promise<any>;
}

declare global {
  interface Window {
    solana?: PhantomProvider;
  }
}

export const usePhantomWallet = () => {
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isPhantomInstalled, setIsPhantomInstalled] = useState(false);

  useEffect(() => {
    const checkPhantom = () => {
      const provider = window.solana;
      if (provider?.isPhantom) {
        setIsPhantomInstalled(true);
        if (provider.isConnected && provider.publicKey) {
          setWalletAddress(provider.publicKey.toString());
        }
      }
    };

    // Phantom injects after load sometimes
    if (document.readyState === "complete") {
      checkPhantom();
    } else {
      window.addEventListener("load", checkPhantom);
      return () => window.removeEventListener("load", checkPhantom);
    }
  }, []);

  useEffect(() => {
    const provider = window.solana;
    if (!provider) return;

    const handleConnect = () => {
      if (provider.publicKey) {
        setWalletAddress(provider.publicKey.toString());
      }
    };
    const handleDisconnect = () => setWalletAddress(null);

    provider.on("connect", handleConnect);
    provider.on("disconnect", handleDisconnect);
    return () => {
      provider.off("connect", handleConnect);
      provider.off("disconnect", handleDisconnect);
    };
  }, [isPhantomInstalled]);

  const connect = useCallback(async () => {
    const provider = window.solana;
    if (!provider?.isPhantom) {
      window.open("https://phantom.app/", "_blank");
      return;
    }
    setIsConnecting(true);
    try {
      const resp = await provider.connect();
      setWalletAddress(resp.publicKey.toString());
    } catch (err) {
      console.error("Wallet connection failed:", err);
    } finally {
      setIsConnecting(false);
    }
  }, []);

  const disconnect = useCallback(async () => {
    const provider = window.solana;
    if (provider) {
      await provider.disconnect();
      setWalletAddress(null);
    }
  }, []);

  return {
    walletAddress,
    isConnecting,
    isPhantomInstalled,
    connect,
    disconnect,
  };
};
