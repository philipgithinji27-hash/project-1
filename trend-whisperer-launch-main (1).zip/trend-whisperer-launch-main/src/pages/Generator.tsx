import { Sparkles, Edit3 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

const Generator = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-display font-bold tracking-wide neon-text-cyan">
          AI TOKEN GENERATOR
        </h1>
        <p className="text-muted-foreground text-sm font-body mt-1">
          Select a trend to generate meme coin concepts
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Trend Selection */}
        <Card className="bg-card/80 neon-border backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="font-display text-lg tracking-wide flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-secondary" />
              SELECT TREND
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {["AI Agents", "RWA Tokens", "DePIN", "Meme Dogs", "Solana Gaming"].map((trend) => (
              <button
                key={trend}
                className="w-full text-left p-3 rounded-md bg-muted/30 hover:bg-primary/10 hover:neon-border transition-all font-body"
              >
                {trend}
              </button>
            ))}
          </CardContent>
        </Card>

        {/* Generated Token */}
        <Card className="bg-card/80 neon-border backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="font-display text-lg tracking-wide flex items-center gap-2">
              <Edit3 className="h-5 w-5 text-neon-yellow" />
              TOKEN CONCEPT
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-mono text-muted-foreground uppercase">Token Name</label>
              <Input placeholder="e.g. AgentDAO" className="bg-muted/30 border-border/50 font-body" />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-mono text-muted-foreground uppercase">Ticker</label>
              <Input placeholder="e.g. AGNT" className="bg-muted/30 border-border/50 font-body" />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-mono text-muted-foreground uppercase">Lore</label>
              <Textarea
                placeholder="Token lore and backstory..."
                className="bg-muted/30 border-border/50 font-body min-h-[100px]"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-mono text-muted-foreground uppercase">Tagline</label>
              <Input placeholder="e.g. The future of autonomous finance" className="bg-muted/30 border-border/50 font-body" />
            </div>
            <Button className="w-full font-display tracking-wider neon-glow-cyan">
              <Sparkles className="h-4 w-4 mr-2" />
              GENERATE WITH AI
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Generator;
