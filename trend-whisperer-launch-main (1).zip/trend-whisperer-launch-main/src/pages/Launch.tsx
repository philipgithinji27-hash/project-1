import { useState } from "react";
import { Rocket, Wallet, Shield, CheckCircle, ExternalLink, Droplets, Zap } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { usePhantomWallet } from "@/hooks/usePhantomWallet";
import { toast } from "sonner";

const Launch = () => {
  const { walletAddress, isConnecting, isPhantomInstalled, connect, disconnect } = usePhantomWallet();
  const [isLaunching, setIsLaunching] = useState(false);

  const shortAddress = walletAddress
    ? `${walletAddress.slice(0, 4)}...${walletAddress.slice(-4)}`
    : null;

  const handleLaunch = async () => {
    if (!walletAddress) {
      toast.error("Connect your Phantom wallet first");
      return;
    }
    setIsLaunching(true);
    try {
      // pump.fun launch would go here — requires Phantom signing
      toast.info("Launch flow initiated — Phantom will prompt for signing");
      // After launch, token auto-migrates to Raydium when bonding curve completes
    } catch (err) {
      toast.error("Launch failed — check console for details");
      console.error(err);
    } finally {
      setIsLaunching(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-display font-bold tracking-wide neon-text-cyan">
          TOKEN LAUNCH
        </h1>
        <p className="text-muted-foreground text-sm font-body mt-1">
          Review, connect wallet, and approve your token launch
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Token Preview */}
        <Card className="lg:col-span-2 bg-card/80 neon-border backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="font-display text-lg tracking-wide flex items-center gap-2">
              <Rocket className="h-5 w-5 text-primary" />
              TOKEN PREVIEW
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-mono text-muted-foreground uppercase">Name</label>
                <Input value="AgentDAO" readOnly className="bg-muted/30 border-border/50 font-body" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-mono text-muted-foreground uppercase">Symbol</label>
                <Input value="AGNT" readOnly className="bg-muted/30 border-border/50 font-body" />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-mono text-muted-foreground uppercase">Supply</label>
              <Input value="1,000,000,000" readOnly className="bg-muted/30 border-border/50 font-body" />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-mono text-muted-foreground uppercase">Description</label>
              <Textarea
                value="The autonomous AI agent governance token powering the next generation of DeFi."
                readOnly
                className="bg-muted/30 border-border/50 font-body"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-mono text-muted-foreground uppercase">Logo</label>
              <div className="w-20 h-20 rounded-lg bg-muted/50 neon-border flex items-center justify-center text-muted-foreground text-xs font-mono">
                Upload
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Wallet & Launch */}
        <div className="space-y-4">
          <Card className="bg-card/80 neon-border backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="font-display text-sm tracking-wide flex items-center gap-2">
                <Wallet className="h-4 w-4 text-neon-purple" />
                WALLET
              </CardTitle>
            </CardHeader>
            <CardContent>
              {walletAddress ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 p-2 rounded-md bg-neon-green/10 border border-neon-green/20">
                    <CheckCircle className="h-4 w-4 text-neon-green flex-shrink-0" />
                    <span className="text-xs font-mono text-neon-green truncate">{shortAddress}</span>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={disconnect}
                    className="w-full font-display text-xs tracking-wider border-destructive/30 hover:bg-destructive/10 text-destructive"
                  >
                    DISCONNECT
                  </Button>
                </div>
              ) : (
                <Button
                  variant="outline"
                  onClick={connect}
                  disabled={isConnecting}
                  className="w-full font-display text-xs tracking-wider border-neon-purple/30 hover:bg-neon-purple/10"
                >
                  <Wallet className="h-4 w-4 mr-2" />
                  {isConnecting
                    ? "CONNECTING..."
                    : isPhantomInstalled
                    ? "CONNECT PHANTOM"
                    : "INSTALL PHANTOM"}
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Raydium Liquidity Info */}
          <Card className="bg-card/80 neon-border backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="font-display text-sm tracking-wide flex items-center gap-2">
                <Droplets className="h-4 w-4 text-primary" />
                RAYDIUM LIQUIDITY
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-xs font-mono text-muted-foreground">
              <p className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-neon-green" />
                Auto-migrates to Raydium on bonding curve completion
              </p>
              <p className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-neon-green" />
                LP tokens burned for permanent liquidity
              </p>
              <a
                href="https://raydium.io/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-primary hover:underline mt-1"
              >
                Learn more <ExternalLink className="h-3 w-3" />
              </a>
            </CardContent>
          </Card>

          <Card className="bg-card/80 neon-border backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="font-display text-sm tracking-wide flex items-center gap-2">
                <Shield className="h-4 w-4 text-neon-green" />
                SAFETY CHECK
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-xs font-mono text-muted-foreground">
              <p className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-neon-green" />
                No private keys stored
              </p>
              <p className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-neon-green" />
                Manual approval required
              </p>
              <p className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-neon-green" />
                No rate limit — unlimited launches
              </p>
            </CardContent>
          </Card>

          <Button
            className="w-full font-display tracking-wider neon-glow-cyan h-12"
            disabled={!walletAddress || isLaunching}
            onClick={handleLaunch}
          >
            {isLaunching ? (
              <>
                <Zap className="h-4 w-4 mr-2 animate-pulse" />
                LAUNCHING...
              </>
            ) : walletAddress ? (
              <>
                <Rocket className="h-4 w-4 mr-2" />
                APPROVE & LAUNCH
              </>
            ) : (
              <>
                <Wallet className="h-4 w-4 mr-2" />
                CONNECT WALLET FIRST
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Launch;
