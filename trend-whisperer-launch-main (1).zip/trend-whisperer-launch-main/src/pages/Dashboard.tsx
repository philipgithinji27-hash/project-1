import { TrendingUp, Activity, Zap, BarChart3 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const mockTrends = [
  { name: "AI Agents", score: 92, velocity: "+340%", risk: "Low" },
  { name: "RWA Tokens", score: 85, velocity: "+210%", risk: "Medium" },
  { name: "DePIN", score: 78, velocity: "+180%", risk: "Low" },
  { name: "Meme Dogs", score: 71, velocity: "+150%", risk: "High" },
  { name: "Solana Gaming", score: 65, velocity: "+120%", risk: "Medium" },
];

const stats = [
  { label: "Active Trends", value: "24", icon: TrendingUp, color: "text-neon-cyan" },
  { label: "Tweet Velocity", value: "12.4K/hr", icon: Activity, color: "text-neon-magenta" },
  { label: "New Launches", value: "156", icon: Zap, color: "text-neon-yellow" },
  { label: "Avg Volume", value: "$2.1M", icon: BarChart3, color: "text-neon-green" },
];

const Dashboard = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-display font-bold tracking-wide neon-text-cyan">
          TREND DASHBOARD
        </h1>
        <p className="text-muted-foreground text-sm font-body mt-1">
          Real-time crypto narrative tracking & analysis
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Card key={stat.label} className="bg-card/80 neon-border backdrop-blur-sm">
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`p-2 rounded-md bg-muted ${stat.color}`}>
                <stat.icon className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground font-mono uppercase">{stat.label}</p>
                <p className="text-xl font-display font-bold">{stat.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Trending Narratives */}
      <Card className="bg-card/80 neon-border backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="font-display text-lg tracking-wide flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            TRENDING NARRATIVES
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {mockTrends.map((trend, i) => (
              <div
                key={trend.name}
                className="flex items-center justify-between p-3 rounded-md bg-muted/30 hover:bg-muted/50 transition-colors cursor-pointer neon-border"
              >
                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono text-muted-foreground w-6">
                    #{i + 1}
                  </span>
                  <span className="font-body font-semibold">{trend.name}</span>
                </div>
                <div className="flex items-center gap-2 sm:gap-4 flex-wrap sm:flex-nowrap">
                  <span className="text-sm font-mono text-neon-green">{trend.velocity}</span>
                  <div className="hidden sm:block w-24 bg-muted rounded-full h-2">
                    <div
                      className="h-2 rounded-full bg-primary"
                      style={{ width: `${trend.score}%` }}
                    />
                  </div>
                  <span
                    className={`text-xs font-mono px-2 py-0.5 rounded ${
                      trend.risk === "Low"
                        ? "bg-neon-green/10 text-neon-green"
                        : trend.risk === "Medium"
                        ? "bg-neon-yellow/10 text-neon-yellow"
                        : "bg-destructive/10 text-destructive"
                    }`}
                  >
                    {trend.risk}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;
