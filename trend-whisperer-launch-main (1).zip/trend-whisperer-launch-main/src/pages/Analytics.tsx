import { BarChart3, TrendingUp, Droplets, Users } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const Analytics = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-display font-bold tracking-wide neon-text-cyan">
          POST-LAUNCH ANALYTICS
        </h1>
        <p className="text-muted-foreground text-sm font-body mt-1">
          Track your launched tokens in real-time
        </p>
      </div>

      {/* Placeholder Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { label: "24h Volume", value: "$0", icon: BarChart3, color: "text-neon-cyan" },
          { label: "Liquidity", value: "$0", icon: Droplets, color: "text-neon-magenta" },
          { label: "Holders", value: "0", icon: Users, color: "text-neon-green" },
        ].map((stat) => (
          <Card key={stat.label} className="bg-card/80 neon-border backdrop-blur-sm">
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`p-2 rounded-md bg-muted ${stat.color}`}>
                <stat.icon className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground font-mono uppercase">{stat.label}</p>
                <p className="text-xl font-display font-bold">{stat.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Chart Placeholder */}
      <Card className="bg-card/80 neon-border backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="font-display text-lg tracking-wide flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            PRICE CHART
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex items-center justify-center text-muted-foreground font-mono text-sm">
            No launched tokens yet. Launch a token to see analytics.
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Analytics;
