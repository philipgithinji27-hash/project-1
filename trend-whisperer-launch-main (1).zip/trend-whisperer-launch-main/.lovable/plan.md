
# TrendLaunch – Smart Meme Coin Launch Assistant

## Overview
A dark, cyberpunk-styled web app that aggregates crypto trend data, uses AI to generate meme coin concepts, and lets users launch tokens on pump.fun via Phantom wallet — all with manual approval.

---

## Phase 1: Foundation & Dashboard UI
Build the core layout with a dark/cyberpunk design system (neon accents, dark backgrounds, glowing borders).

**Pages:**
- **Dashboard** — Main hub showing trending narratives, heatmap, velocity metrics
- **Generator** — AI token creator with editable fields
- **Launch** — Token preview + wallet connect + approval
- **Analytics** — Post-launch tracking

**Navigation:** Sidebar or top nav with neon-styled active states

---

## Phase 2: Trend Aggregator (Backend + Frontend)
Enable Lovable Cloud and create edge functions to fetch live data:

- **DexScreener API** — Trending pairs, volume changes, liquidity, holder growth (free public API)
- **Twitter/X API** — Search for Solana/memecoin trends, extract tweet velocity and engagement (using your Twitter API key)
- **Pump.fun data** — Recent launches, market cap, bonding curve progress (via Firecrawl scraping if no public API)

Display top 10 trending narratives with saturation and competition scores in the dashboard.

---

## Phase 3: AI Meme Coin Generator
Use Lovable AI to generate token concepts when a user selects a trend:
- Token name & ticker (3-5 letters)
- Lore paragraph & tagline
- Launch strategy suggestion
- All fields editable by the user before proceeding

---

## Phase 4: Risk Engine
Score each trend/token idea based on:
- Similar tokens launched in last 24h
- Liquidity duplication signals
- Narrative fatigue level

Display as Low / Medium / High saturation badges with visual indicators.

---

## Phase 5: Wallet Connection & Token Launch
- Integrate Solana Wallet Adapter with Phantom support
- Build the launch preview page (name, symbol, supply, description, logo upload)
- "Approve & Launch" button triggers pump.fun API call
- Phantom wallet popup for transaction signing — no auto-sign, no key storage
- Rate limit: max 1 launch per 24 hours

---

## Phase 6: Post-Launch Analytics
- Track launched tokens: volume, liquidity, holder count
- Pull data from DexScreener for the launched token's mint address
- Display charts using Recharts

---

## Safety & Compliance
- No automated loops or batch launching
- No private key storage
- Manual user approval required for every launch
- API rate limit compliance built into all edge functions
- Clear error handling for 429/402 responses
