const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

interface DexPair {
  chainId: string;
  dexId: string;
  pairAddress: string;
  baseToken: { address: string; name: string; symbol: string };
  quoteToken: { address: string; name: string; symbol: string };
  priceUsd: string;
  txns: { h24: { buys: number; sells: number } };
  volume: { h24: number };
  priceChange: { h24: number };
  liquidity: { usd: number };
  fdv: number;
  pairCreatedAt: number;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Fetch trending tokens on Solana from DexScreener
    const [trendingRes, boostRes] = await Promise.all([
      fetch('https://api.dexscreener.com/token-boosts/top/v1'),
      fetch('https://api.dexscreener.com/token-profiles/latest/v1'),
    ]);

    const trending = await trendingRes.json();
    const boosted = await boostRes.json();

    // Filter for Solana pairs only
    const solanaTrending = (Array.isArray(trending) ? trending : [])
      .filter((t: any) => t.chainId === 'solana')
      .slice(0, 20);

    // Get detailed pair data for top tokens
    const tokenAddresses = solanaTrending
      .map((t: any) => t.tokenAddress)
      .filter(Boolean)
      .slice(0, 10);

    let pairs: DexPair[] = [];
    if (tokenAddresses.length > 0) {
      const pairsRes = await fetch(
        `https://api.dexscreener.com/tokens/v1/solana/${tokenAddresses.join(',')}`
      );
      const pairsData = await pairsRes.json();
      pairs = Array.isArray(pairsData) ? pairsData : [];
    }

    // Aggregate into trending narratives by grouping similar tokens
    const narratives = pairs
      .filter((p) => p.volume?.h24 > 0)
      .map((p) => ({
        name: p.baseToken?.name || 'Unknown',
        symbol: p.baseToken?.symbol || '???',
        address: p.baseToken?.address,
        pairAddress: p.pairAddress,
        priceUsd: p.priceUsd,
        volume24h: p.volume?.h24 || 0,
        priceChange24h: p.priceChange?.h24 || 0,
        liquidity: p.liquidity?.usd || 0,
        fdv: p.fdv || 0,
        buys24h: p.txns?.h24?.buys || 0,
        sells24h: p.txns?.h24?.sells || 0,
        createdAt: p.pairCreatedAt,
      }))
      .sort((a, b) => b.volume24h - a.volume24h)
      .slice(0, 10);

    // Calculate aggregate stats
    const stats = {
      totalVolume: narratives.reduce((sum, n) => sum + n.volume24h, 0),
      totalLiquidity: narratives.reduce((sum, n) => sum + n.liquidity, 0),
      avgPriceChange: narratives.length
        ? narratives.reduce((sum, n) => sum + n.priceChange24h, 0) / narratives.length
        : 0,
      activePairs: pairs.length,
    };

    console.log(`Fetched ${narratives.length} Solana trending pairs`);

    return new Response(
      JSON.stringify({ success: true, narratives, stats, boosted: solanaTrending }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('DexScreener fetch error:', error);
    return new Response(
      JSON.stringify({ success: false, error: error instanceof Error ? error.message : 'Failed to fetch' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
