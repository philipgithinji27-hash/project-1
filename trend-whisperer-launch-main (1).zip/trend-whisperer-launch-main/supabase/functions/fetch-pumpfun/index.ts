const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const firecrawlKey = Deno.env.get('FIRECRAWL_API_KEY');

    let launches: any[] = [];

    if (firecrawlKey) {
      // Use Firecrawl to scrape pump.fun for recent launches
      const scrapeRes = await fetch('https://api.firecrawl.dev/v1/scrape', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${firecrawlKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          url: 'https://pump.fun/board',
          formats: [
            'markdown',
            {
              type: 'json',
              prompt: 'Extract all token launches visible on this page. For each token, extract: name, ticker/symbol, market cap, description, creator address, creation time, bonding curve progress percentage, and number of replies/comments.',
              schema: {
                type: 'object',
                properties: {
                  tokens: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        name: { type: 'string' },
                        symbol: { type: 'string' },
                        marketCap: { type: 'string' },
                        description: { type: 'string' },
                        creator: { type: 'string' },
                        createdAt: { type: 'string' },
                        bondingProgress: { type: 'number' },
                        replies: { type: 'number' },
                      },
                    },
                  },
                },
              },
            },
          ],
          waitFor: 3000,
        }),
      });

      const scrapeData = await scrapeRes.json();
      const extracted = scrapeData?.data?.json || scrapeData?.json;
      launches = extracted?.tokens || [];
      console.log(`Firecrawl: extracted ${launches.length} pump.fun launches`);
    } else {
      // Fallback: use pump.fun's public API endpoints if available
      try {
        const res = await fetch('https://frontend-api-v3.pump.fun/coins/latest?limit=20&offset=0&includeNsfw=false');
        if (res.ok) {
          const data = await res.json();
          launches = (Array.isArray(data) ? data : []).map((t: any) => ({
            name: t.name,
            symbol: t.symbol,
            marketCap: t.market_cap?.toString() || '0',
            description: t.description || '',
            creator: t.creator,
            createdAt: t.created_timestamp ? new Date(t.created_timestamp).toISOString() : '',
            bondingProgress: t.bonding_curve_progress || 0,
            replies: t.reply_count || 0,
            imageUri: t.image_uri,
            mint: t.mint,
          }));
          console.log(`pump.fun API: fetched ${launches.length} launches`);
        }
      } catch (e) {
        console.error('pump.fun API fallback failed:', e);
      }
    }

    // Calculate saturation metrics
    const nameWords = launches.flatMap((l) =>
      (l.name || '').toLowerCase().split(/\s+/)
    );
    const wordCounts = new Map<string, number>();
    for (const w of nameWords) {
      if (w.length > 2) wordCounts.set(w, (wordCounts.get(w) || 0) + 1);
    }

    const saturatedTerms = [...wordCounts.entries()]
      .filter(([, count]) => count > 2)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([term, count]) => ({ term, count }));

    return new Response(
      JSON.stringify({
        success: true,
        launches,
        totalLaunches: launches.length,
        saturatedTerms,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('pump.fun fetch error:', error);
    return new Response(
      JSON.stringify({ success: false, error: error instanceof Error ? error.message : 'Failed to fetch' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
