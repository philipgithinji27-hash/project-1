const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const bearerToken = Deno.env.get('TWITTER_BEARER_TOKEN');
    if (!bearerToken) {
      return new Response(
        JSON.stringify({ success: false, error: 'Twitter Bearer Token not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { query } = await req.json().catch(() => ({ query: undefined }));

    // Search queries for crypto/memecoin trends
    const searchQueries = [
      '(solana OR $SOL) (memecoin OR meme) -is:retweet lang:en',
      '(pump.fun OR pumpfun) -is:retweet lang:en',
      query ? `${query} solana -is:retweet lang:en` : null,
    ].filter(Boolean);

    const results = await Promise.all(
      searchQueries.map(async (q) => {
        const params = new URLSearchParams({
          query: q!,
          max_results: '20',
          'tweet.fields': 'created_at,public_metrics,entities',
          sort_order: 'relevancy',
        });

        const res = await fetch(
          `https://api.x.com/2/tweets/search/recent?${params}`,
          {
            headers: { Authorization: `Bearer ${bearerToken}` },
          }
        );

        if (!res.ok) {
          const errText = await res.text();
          console.error(`Twitter API error (${res.status}):`, errText);
          return { query: q, tweets: [], error: `${res.status}: ${errText}` };
        }

        const data = await res.json();
        return { query: q, tweets: data.data || [], meta: data.meta };
      })
    );

    // Extract trending topics from tweets
    const allTweets = results.flatMap((r) => r.tweets);
    const hashtagCounts = new Map<string, { count: number; engagement: number }>();

    for (const tweet of allTweets) {
      const hashtags = tweet.entities?.hashtags || [];
      const engagement =
        (tweet.public_metrics?.like_count || 0) +
        (tweet.public_metrics?.retweet_count || 0) +
        (tweet.public_metrics?.reply_count || 0);

      for (const ht of hashtags) {
        const tag = ht.tag.toLowerCase();
        const existing = hashtagCounts.get(tag) || { count: 0, engagement: 0 };
        hashtagCounts.set(tag, {
          count: existing.count + 1,
          engagement: existing.engagement + engagement,
        });
      }
    }

    // Sort by engagement and return top trending
    const trendingTopics = [...hashtagCounts.entries()]
      .map(([tag, data]) => ({ tag, ...data }))
      .sort((a, b) => b.engagement - a.engagement)
      .slice(0, 15);

    const tweetVelocity = allTweets.length;

    console.log(`Fetched ${allTweets.length} tweets, ${trendingTopics.length} topics`);

    return new Response(
      JSON.stringify({
        success: true,
        trendingTopics,
        tweetVelocity,
        totalTweets: allTweets.length,
        searchResults: results.map((r) => ({
          query: r.query,
          count: r.tweets.length,
          error: r.error,
        })),
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Twitter fetch error:', error);
    return new Response(
      JSON.stringify({ success: false, error: error instanceof Error ? error.message : 'Failed to fetch' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
